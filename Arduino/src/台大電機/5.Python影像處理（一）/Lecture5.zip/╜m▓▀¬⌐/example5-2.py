from PIL import Image
import numpy as np

with Image.open('lenna.png') as img:
	lenna = np.array(img)
	print(lenna.shape)

import scipy.misc

lenna_r = np.zeros(lenna.shape)

lenna_r[:,:,0] = lenna[:,:,0]

scipy.misc.imsave('lenna_r.jpg',lenna_r)