from PIL import Image
import numpy as np
import cv2
import scipy.misc

with Image.open('lenna_gray.jpg') as img:
 	img = np.array(img)
 	#lennaGray = img[:,:,0]

lennaGrayHalf = np.round(img/2).astype(np.uint8)
lennaGrayHist = cv2.equalizeHist(lennaGrayHalf)
scipy.misc.imsave('lenna_gray_half.jpg',lennaGrayHalf)
scipy.misc.imsave('lenna_gray_hist.jpg',lennaGrayHist)