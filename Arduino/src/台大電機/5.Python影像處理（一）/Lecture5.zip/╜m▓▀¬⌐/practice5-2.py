from PIL import Image
import numpy as np
import scipy.misc
import math

with Image.open('lenna.png') as img:
	lenna = np.array(img)

lennaReduceRed = lenna
#Write your code here

scipy.misc.imsave('lenna_reduce_red.jpg',lennaReduceRed)

lennaGray = np.zeros(lenna.shape)
#Write your code here

scipy.misc.imsave('lenna_gray.jpg',lennaGray)

