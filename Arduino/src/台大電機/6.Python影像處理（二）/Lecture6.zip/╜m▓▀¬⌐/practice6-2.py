from PIL import Image
import numpy as np
import cv2
import scipy.misc
import matplotlib.pyplot as plt


with Image.open('25_18.jpg') as img:
 	img = np.array(img)
 	picture = img[:,:,0]
my_list=[]
axiss=[]

test=1
while test<50:
	




	
	maxx=np.max(result)
	my_list.append(maxx)
	axiss.append(test)
	print (maxx,test)
	#scipy.misc.imsave('img'+str(test)+'.jpg',result)
	test=test+1

plt.title('Result')
plt.plot(axiss,my_list,color='pink',linestyle='--')
plt.show()